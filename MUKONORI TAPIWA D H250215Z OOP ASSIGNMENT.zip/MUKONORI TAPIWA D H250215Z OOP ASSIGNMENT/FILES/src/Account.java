public abstract class Account {
    protected String accountNumber;
    protected double balance;

    public Account(String accountNumber, double openingBalance) {
        this.accountNumber = accountNumber;
        this.balance = openingBalance;
    }

    // Shared behaviour: identical for every account type
    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("[" + accountNumber + "] Deposit rejected: amount must be positive.");
            return;
        }
        balance += amount;
        System.out.printf("[%s] Deposited %.2f. Balance: %.2f%n", accountNumber, amount, balance);
    }

    public double getBalance() {
        return balance;
    }

    // Behaviour that differs: each subclass supplies its own version
    public abstract void withdraw(double amount);

    public abstract void endOfMonth();
}
