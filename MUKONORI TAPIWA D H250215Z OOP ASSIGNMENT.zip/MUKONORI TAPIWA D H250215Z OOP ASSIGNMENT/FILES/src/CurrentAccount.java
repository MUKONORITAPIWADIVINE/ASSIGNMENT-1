public class CurrentAccount extends Account {
    private static final double MONTHLY_FEE = 5.00; // fixed maintenance fee
    private final double overdraftLimit;

    public CurrentAccount(String accountNumber, double openingBalance, double overdraftLimit) {
        super(accountNumber, openingBalance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("[" + accountNumber + "] Withdrawal rejected: amount must be positive.");
        } else if (balance - amount < -overdraftLimit) {
            System.out.printf("[%s] CURRENT withdrawal of %.2f REJECTED: would exceed overdraft limit of %.2f.%n",
                    accountNumber, amount, overdraftLimit);
        } else {
            balance -= amount;
            String note = balance < 0 ? " (in overdraft)" : "";
            System.out.printf("[%s] CURRENT withdrew %.2f. Balance: %.2f%s%n",
                    accountNumber, amount, balance, note);
        }
    }

    @Override
    public void endOfMonth() {
        balance -= MONTHLY_FEE;
        System.out.printf("[%s] CURRENT month-end: fee %.2f deducted. Balance: %.2f%n",
                accountNumber, MONTHLY_FEE, balance);
    }
}
