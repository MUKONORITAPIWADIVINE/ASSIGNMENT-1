public class SavingsAccount extends Account {
    private static final double INTEREST_RATE = 0.02; // 2% fixed
    private final double minimumBalance;

    public SavingsAccount(String accountNumber, double openingBalance, double minimumBalance) {
        super(accountNumber, openingBalance);
        this.minimumBalance = minimumBalance;
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("[" + accountNumber + "] Withdrawal rejected: amount must be positive.");
        } else if (balance - amount < minimumBalance) {
            System.out.printf("[%s] SAVINGS withdrawal of %.2f REJECTED: balance would fall below the minimum of %.2f.%n",
                    accountNumber, amount, minimumBalance);
        } else {
            balance -= amount;
            System.out.printf("[%s] SAVINGS withdrew %.2f. Balance: %.2f%n", accountNumber, amount, balance);
        }
    }

    @Override
    public void endOfMonth() {
        double interest = balance * INTEREST_RATE;
        balance += interest;
        System.out.printf("[%s] SAVINGS month-end: interest %.2f added. Balance: %.2f%n",
                accountNumber, interest, balance);
    }
}
