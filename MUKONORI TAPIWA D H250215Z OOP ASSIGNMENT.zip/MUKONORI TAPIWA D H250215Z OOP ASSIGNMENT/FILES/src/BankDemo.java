import java.util.ArrayList;
import java.util.List;

public class BankDemo {
    public static void main(String[] args) {
        List<Account> accounts = new ArrayList<>();
        accounts.add(new SavingsAccount("SAV-001", 1000.00, 100.00));
        accounts.add(new CurrentAccount("CUR-001", 200.00, 300.00));
        accounts.add(new SavingsAccount("SAV-002", 150.00, 100.00));

        System.out.println("=== Round 1: withdraw 100 from every account ===");
        for (Account a : accounts) {
            a.withdraw(100.00);   // no casting: Java picks the right version at runtime
        }

        System.out.println("\n=== Round 2: withdraw 350 from every account ===");
        for (Account a : accounts) {
            a.withdraw(350.00);
        }

        System.out.println("\n=== Round 3: withdraw 100 again (tests the overdraft limit) ===");
        for (Account a : accounts) {
            a.withdraw(100.00);
        }

        System.out.println("\n=== Month end ===");
        for (Account a : accounts) {
            a.endOfMonth();       // interest for savings, fee for current
        }

        System.out.println("\n=== Final balances ===");
        for (Account a : accounts) {
            System.out.printf("%s -> %.2f%n", a.accountNumber, a.getBalance());
        }
    }
}
